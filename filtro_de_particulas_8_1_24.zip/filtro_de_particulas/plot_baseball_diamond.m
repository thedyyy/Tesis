function plot_sphere_custom_parameters(radius, num_points, max_height, alpha)

    % Generar puntos aleatorios en una esfera con radio dado
    theta = 2 * pi * rand(1, num_points);
    phi = acos(2 * rand(1, num_points) - 1);
    r = radius * (rand(1, num_points).^(1/3));

    % Convertir a coordenadas cartesianas
    x_sphere = r .* sin(phi) .* cos(theta);
    y_sphere = r .* cos(phi); % Cambiando y por cos(phi)
    z_sphere = r .* sin(phi) .* sin(theta); % Cambiando z por sin(phi) * sin(theta)

    % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
    x_min = min(x_sphere);
    x_sphere = x_sphere - x_min;

    % Visualizar puntos antes de la eliminación
    figure;
    scatter3(x_sphere, y_sphere, z_sphere, 'o', 'MarkerFaceColor', 'b');
    title('Puntos en la Esfera antes de Eliminación');
    xlabel('X-axis');
    ylabel('Y-axis');
    zlabel('Z-axis');
    axis equal;
    grid on;

    % Definir límites del "diamante" y de la altura
    angle_lower_limit = -alpha / 2; % Límite inferior del rango angular en grados
    angle_upper_limit = alpha / 2; % Límite superior del rango angular en grados
    height_lower_limit = -max_height; % Límite inferior de la altura
    height_upper_limit = max_height; % Límite superior de la altura

    % Filtrar puntos fuera del "diamante" y del límite de altura
    angles = atan2d(y_sphere, x_sphere); % Cambiando el ángulo para reflejar el cambio de coordenadas
    distances = sqrt(x_sphere.^2 + y_sphere.^2 + z_sphere.^2);

    %valid_indices = find(angles >= angle_lower_limit & angles <= angle_upper_limit & ...
%                          y_sphere >= height_lower_limit & y_sphere <= height_upper_limit & ...
%                          distances <= radius);

    valid_indices = find(angles >= angle_lower_limit & angles <= angle_upper_limit & ...
                     y_sphere >= height_lower_limit & y_sphere <= height_upper_limit & ...
                     z_sphere >= -0.6 & distances <= radius);

    % Seleccionar solo los puntos válidos
    x_valid = x_sphere(valid_indices);
    y_valid = y_sphere(valid_indices);
    z_valid = z_sphere(valid_indices);

    % Crear matriz de partículas
    particle_matrix = zeros(4, num_points);
    
    % Asignar valores a las partículas dentro del volumen
    particle_matrix(1:3, valid_indices) = [x_sphere(valid_indices); y_sphere(valid_indices); z_sphere(valid_indices)];
    particle_matrix(4, valid_indices) = 1; % Agregar una cuarta fila de unos para indicar que está dentro del volumen

    particle_matrix
    
    % Visualizar puntos después de la eliminación
    figure;
    scatter3(x_valid, y_valid, z_valid, 'o', 'MarkerFaceColor', 'r');
    title('Puntos en la Esfera después de Eliminación');
    xlabel('X-axis');
    ylabel('Y-axis');
    zlabel('Z-axis');
    axis equal;
    grid on;

end






