radio=30
altura=5
fov_deg=60
sigma_velo=0.1
filter.J_max= 1000

ProyectionMatrix = [211.06312561, 0.0, 101.45460085,0;  
                    0.0, 156.13174438,  55.23133321,0;
                    0.0, 0.0, 1.0 , 0.0 ];
Haxis = createHomogeneousMatrixFromROS(0.0, 0.0, 0.0, -1.5708, 0.0, -1.5708);
Hcam = createHomogeneousMatrixFromROS(0.0, 0.0, 0.35, 0.0, 0.0, 0.0);
model.H = ProyectionMatrix* (inv(Hcam*Haxis))

x_update=init_distribution(filter.J_max,radio,altura,fov_deg,sigma_velo)
x_update=x_update([1,3,5],:);
x_h=x_update;
x_h(4,:)=1
x_proyect=model.H*x_h
x_final=x_proyect(1:2, :) ./ x_proyect(3, :)
x2=x_final(1,:);
y2=x_final(2,:);
figure;
plot(x2, y2, 'o');
axis([0,160 , 0,120])
xlabel('X');
ylabel('Y');
title('Vectores en el Plano XY')

x_final

mu = [66.2856, 52.4782];

% Calcular la matriz de covarianza sigma según tus necesidades
% Supongamos que sigma es la matriz de covarianza
% Puedes ajustar esta parte según la covarianza que desees utilizar
sigma = eye(2)

pdf_values = mvnpdf(x_final', mu, sigma)


