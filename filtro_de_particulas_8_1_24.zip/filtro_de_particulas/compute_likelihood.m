%function qz= compute_likelihood(model,z,X)

% compute likelihood vector g= [ log_g(z|x_1), ... , log_g(z|x_M) ] -
% this is for bearings and range case with additive Gaussian noise

%z_hat = model.H * X;

%qz = normpdf(z_hat, z, model.R);

function qz = compute_likelihood(model, z, X, fov_deg, altura, radio ,k)
    % Obtener solo los valores de x, y, y z de X
    
    %x_y_z_vector = X([1; 3; 5]);
   
    %X = torta(X,fov_deg,altura,radio);
    
    x_y_z_vector = X([1, 3, 5], :);

%     a = x_y_z_vector(1, :);
%     b = x_y_z_vector(2, :);
%     c = x_y_z_vector(3, :);
%     
%     figure;
%     scatter3(a, b, c, 'filled');
%     xlabel('X');
%     ylabel('Y');
%     zlabel('Z');
%     title('Distribución Aleatoria de Puntos en 3D , pre_condicion')    
    
    % x_y_z_homogeneous = [x_y_z_vector; ones(1, size(x_y_z_vector, 2))]; %agrega la ultima fila con puros 1 
    %x_y_z_vector=torta(x_y_z_vector,fov_deg,altura,radio)
    %condition = x_y_z_vector(1, :) = 0 & x_y_z_vector(2, :) = 0 & x_y_z_vector(3, :) = 0;
    %x_y_z_homogeneous(4, condition) = 0;
    %x_y_z_homogeneous(4, ~condition) = 1;
    
    %x_y_z_homogeneous=x_y_z_vector
    
    %x = x_y_z_homogeneous(1, :);
    %y = x_y_z_homogeneous(2, :);
    %z = x_y_z_homogeneous(3, :);
    
    %figure;
    %scatter3(x, y, z, 'filled');
    %xlabel('X');
    %ylabel('Y');
    %zlabel('Z');
    %title('Distribución Aleatoria de Puntos en 3D , post_condicion')
    
    % Agregar un valor 1 para hacerlo un vector homogéneo
    %x_y_z_homogeneous = [x_y_z_vector; 1]

    % Calcular z_hat usando la matriz de modelo H
    
    %z_hat1=x_y_z_vector;
    %z_hat1(4,:)=1;
    particle_matrix = evaluate_points_in_volume(x_y_z_vector , altura , fov_deg,radio ,k); %elimina las particulas fuera del fov
    valid_indices = find(particle_matrix(4, :) == 1) %encuentra los indices de las particulas dentro del fov 
    z_hat1 =particle_matrix(:, valid_indices) %selecciona las particulas con indices validos
    z_hat1 = model.H * z_hat1
    
    %z_hat= z_hat1(1:2) / z_hat1(3); %des-homogeneizaz_hat
    
    % Des-homogeneizar z_hat
    z_hat = z_hat1(1:2, :) ./ z_hat1(3, :);
    
    % Eliminar la fila 3
    if size(z_hat, 1) >= 3
        % Eliminar la fila 3
        z_hat(3, :) = [];
    else
        disp('La matriz z_hat no tiene suficientes filas para eliminar la tercera fila.');
    end 
    
    z_hat;
    


%     z_hat
    z=cell2mat(z);
%     z'
%     sigma = eye(2);
    
    qz1 = mvnpdf(z_hat', z', model.R);
    nuevo_vector = zeros(size(x_y_z_vector, 2), 1);
    
    
 
    nuevo_vector(valid_indices) = qz1;
    qz=nuevo_vector
    

    x2 = z_hat(1, :);
    y2 = z_hat(2, :);

    figure;
    plot(x2, y2, 'o');
    axis([0,160 , 0,120])
    xlabel('X');
    ylabel('Y');
    title(['Vectores en el Plano XY' num2str(k)])   
    
            
end
 


