function H = createHomogeneousMatrixFromROS2(tx, ty, tz, rx, ry, rz)
    rotationMatrix = eul2rotm([rz, ry, rx], 'XYZ');
    
    % Combinar la matriz de rotación y las traslaciones para obtener la matriz homogénea
    H = [rotationMatrix, [tx; ty; tz]; 0, 0, 0, 1];
end
