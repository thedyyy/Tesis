function meas = gen_meas()
    % Especifica la ruta de tu archivo CSV
    archivo_csv = '/home/benjaminthedy/Desktop/results4.csv';

    % Lee el archivo CSV
    tabla_datos = readtable(archivo_csv);

    % variables
    n = size(tabla_datos, 1);
    meas.K = n;
    meas.Z = cell(n, 1); % Cambiado a 1 columna
    meas.hw = cell(n,1);

    % generate measurements
    for k = 1:n
        % Extrae result de los datos de la tabla
        corners = eval(tabla_datos.result{k});

        % Calcula el centro del cuadro delimitador
        
        center_x = (corners(1) + corners(3)) / 2;
        center_y = (corners(2) + corners(4)) / 2;

        % Almacena las coordenadas x e y en una celda
        meas.Z{k} = {center_x; center_y}; % Cada elemento es una celda
        
        width = (corners(1) + corners(3))  ;
        height = (corners(2) + corners(4)) ;

%       
        
        meas.hw{k} = [width ; height] ;
        meas.rect{k} = [[corners(1),corners(2)],[corners(3),corners(2)] ,[corners(1),corners(4)],[corners(3),corners(4)] ];
end








