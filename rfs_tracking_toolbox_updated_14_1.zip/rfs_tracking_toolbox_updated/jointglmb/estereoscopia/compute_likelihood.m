%function qz= compute_likelihood(model,z,X)

% compute likelihood vector g= [ log_g(z|x_1), ... , log_g(z|x_M) ] -
% this is for bearings and range case with additive Gaussian noise

%z_hat = model.H * X;

%qz = normpdf(z_hat, z, model.R);

function qz = compute_likelihood(model, z, X, fov_deg, altura, radio ,k)
    % Obtener solo los valores de x, y, y z de X
    
    
    x_y_z_vector = X([1, 3, 5], :);


    particle_matrix = evaluate_points_in_volume2(x_y_z_vector , altura , fov_deg,radio ,k); %elimina las particulas fuera del fov
    valid_indices = find(particle_matrix(4, :) == 1); %encuentra los indices de las particulas dentro del fov 
    z_hat1 =particle_matrix(:, valid_indices); %selecciona las particulas con indices validos
    z_hat1 = model.H * z_hat1;
    
    %z_hat= z_hat1(1:2) / z_hat1(3); %des-homogeneizaz_hat
    
    % Des-homogeneizar z_hat
    z_hat = z_hat1(1:2, :) ./ z_hat1(3, :);
    
    % Eliminar la fila 3
    if size(z_hat, 1) >= 3
        % Eliminar la fila 3
        z_hat(3, :) = [];
%     else
%         disp('La matriz z_hat no tiene suficientes filas para eliminar la tercera fila.');
    end 
    
    z_hat;
    


%     z_hat
    z=cell2mat(z);
%     z'
%     sigma = eye(2);
    
    qz1 = mvnpdf(z_hat', z', model.R);
    nuevo_vector = zeros(size(x_y_z_vector, 2), 1);
    
    
 
    nuevo_vector(valid_indices) = qz1;
    qz=nuevo_vector;
    

%     x2 = z_hat(1, :);
%     y2 = z_hat(2, :);
% 
%     figure;
%     plot(x2, y2, 'o');
%     axis([0,160 , 0,120])
%     xlabel('X');
%     ylabel('Y');
%     title(['Vectores en el Plano XY' num2str(k)])   
    
            
end
 


