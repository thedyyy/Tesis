function pD = compute_pD(model,X, max_height, alpha, radio, k)

if isempty(X)
    pD= [];
else
    %evaluate_points_in_volume(X, max_height, alpha, radio, k)
    pD=model.P_D*evaluate_points_in_volume(X, max_height, alpha, radio, k);
end
