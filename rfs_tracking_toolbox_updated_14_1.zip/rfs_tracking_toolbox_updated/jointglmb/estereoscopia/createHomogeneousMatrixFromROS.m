function H = createHomogeneousMatrixFromROS(tx, ty, tz, rx, ry, rz)
% Assuming ZYX Euler sequence (rotation around Z, Y, and X axes in order)
seq = 'ZYX';  
H = eul2tform([rz, ry, rx], seq);
H(1:3, 4) = [tx; ty; tz];