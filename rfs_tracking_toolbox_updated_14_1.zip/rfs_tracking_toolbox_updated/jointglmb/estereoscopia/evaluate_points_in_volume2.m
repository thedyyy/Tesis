
function particle_matrix = evaluate_points_in_volume(X, max_height, alpha , radio ,k)

    % Extraer coordenadas x, y, z de la matriz X
    x_sphere = X(1, :);
    y_sphere = X(2, :);
    z_sphere = X(3, :);
%     radio=10

    % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
%     x_min = min(x_sphere);
    x_sphere_adjusted = x_sphere ;

    % Definir límites del "diamante" y de la altura
    angle_lower_limit = -alpha / 2;
    angle_upper_limit = alpha / 2;
    height_lower_limit = -0.7;
    height_upper_limit = max_height;

    % Filtrar puntos dentro del cono
    angles = atan2d(y_sphere, x_sphere_adjusted);
    valid_indices = (angles >= angle_lower_limit) & (angles <= angle_upper_limit) & ...
                    (z_sphere >= height_lower_limit) & (z_sphere <= height_upper_limit)& ...
                    sqrt(x_sphere_adjusted.^2 + y_sphere.^2) <= radio; % Condición para el radio

    % Crear matriz de partículas
    particle_matrix = zeros(4, length(x_sphere));
    
    % Asignar valores a las partículas dentro del cono
    particle_matrix(1:3, valid_indices) = [x_sphere(valid_indices); y_sphere(valid_indices); z_sphere(valid_indices)];
    particle_matrix(4, valid_indices) = 1; % Asignar 1 a la cuarta fila para indicar que está dentro del cono
%     particle_matrix
    
    % Visualizar puntos después de la evaluación
%     figure;
%     scatter3(particle_matrix(1, :), particle_matrix(2, :), particle_matrix(3, :), 'o', 'MarkerFaceColor', 'r');
%     title(['Puntos después de Evaluación frame numero ' num2str(k) ]);
%     xlabel('X-axis');
%     ylabel('Y-axis');
%     zlabel('Z-axis');
%     axis([0, 70, -15, 15, -0.6, 5]);
%     view ([0 90]);
%     
%     grid on;
%     
end










