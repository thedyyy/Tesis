% Generar una nube de puntos aleatoria
num_points = 1000;
X = randn(3, num_points);

% Definir los parámetros
alpha = pi/4;
rho = 20.0;
max_height = 1;

% Obtener las coordenadas x, y, z de cada columna
x = X(1, :);
y = X(2, :);
z = X(3, :);

% Evaluar las condiciones para cada partícula
outside_volume = (z < 0 | z > max_height |sqrt(x.^2 + y.^2) > 5);
X(:, any(outside_volume, 1)) = 0

% Graficar los puntos originales y los puntos transformados
figure;

% Puntos originales en azul
scatter3(x, y, z, 30, 'b', 'filled');
hold on;

% Puntos transformados en rojo
scatter3(X(1, :), X(2, :), X(3, :), 30, 'r', 'filled');

title('Nube de Puntos Original y Transformada');
xlabel('X');
ylabel('Y');
zlabel('Z');
legend('Original', 'Transformado');
grid on;
hold off;
