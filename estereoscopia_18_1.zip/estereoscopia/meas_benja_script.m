% function meas = gen_meas()
%     % Especifica la ruta de tu archivo CSV
%     archivo_csv = '/home/benjaminthedy/Desktop/results4.csv';
% 
%     % Lee el archivo CSV
%     tabla_datos = readtable(archivo_csv);
% 
%     % variables
%     n = size(tabla_datos, 1);
%     meas.K = n;
%     meas.Z = cell(n, 1); % Cambiado a 1 columna
% 
%     % generate measurements
%     for k = 1:n
%         % Extrae result de los datos de la tabla
%         corners = eval(tabla_datos.result{k});
% 
%         % Calcula el centro del cuadro delimitador
%         center_x = (corners(1) + corners(3)) / 2;
%         center_y = (corners(2) + corners(4)) / 2;
% 
%         % Almacena las coordenadas x e y en una celda
%         meas.Z{k} = {center_x; center_y}; % Cada elemento es una celda
%     end
% end






% function meas = gen_meas()
%     % Especifica la ruta de tu archivo CSV
%     archivo_csv = '/home/benjaminthedy/Desktop/results.csv';
% 
%     % Lee el archivo CSV
%     tabla_datos = readtable(archivo_csv);
% 
%     % variables
%     n = size(tabla_datos, 1);
%     meas.K = n;
% 
% %     meas.Z = cell(n, 1); % Una sola columna para todas las mediciones
% 
%     % generate measurements
%     for k = 1:n
%         % Extrae result de los datos de la tabla
%         result_str = tabla_datos.result{k}
% 
%         % Elimina los dobles corchetes externos y convierte la cadena en una matriz
%         result_matrix = str2num(result_str(3:end-2))
% 
%         if isempty(result_matrix)
%             % Si la matriz está vacía, asigna 0 a los valores de x e y
%             meas.Z{k} = [0; 0];
%         else
%             % Inicializa celdas para x e y
%             num_mediciones = numel(result_matrix)/4
%             meas.Z{k, 1} = cell(2, num_mediciones)
%             center_x = zeros(1, num_mediciones)
%             center_y = zeros(1, num_mediciones)
% %             center_x = cell(1, size(result_matrix, 1))
% %             center_y = cell(1, size(result_matrix, 1))
% 
%             for i = 1:4:numel(result_matrix)
%                 % Extract the group of four values
%                 corners = result_matrix(i:i+3)
% 
%                 % Calculate the center of the bounding box
%                 center_x(i) = (corners(1) + corners(3)) / 2
%                 center_y(i) = (corners(2) + corners(4)) / 2
%                 meas.Z{k, 1}{1, i} = center_x(i)
%                 meas.Z{k, 1}{2, i} = center_y(i)
%                 % Your additional processing for this group goes here
%                 disp(['Processing group ', num2str((i+3)/4)]);
%             end
% 
%             % Concatena los resultados de x e y en una celda
% %             meas.Z{k, 1} = [center_x; center_y];
% %             meas.Z{k} = [cell2mat(center_x); cell2mat(center_y)];
%         end
%     end
% end




function meas = gen_meas()
    % Especifica la ruta de tu archivo CSV
    archivo_csv = '/home/benjaminthedy/Desktop/results2_2.csv';

    % Lee el archivo CSV
    tabla_datos = readtable(archivo_csv);

    % variables
    n = size(tabla_datos, 1);
    meas.K = n;

    % generate measurements
    for k = 1:n
        % Extrae result de los datos de la tabla
        result_str = tabla_datos.result{k};

        % Elimina los dobles corchetes externos y convierte la cadena en una matriz
        result_matrix = str2num(result_str(3:end-2));
        

        if isempty(result_matrix)
            % Si la matriz está vacía, asigna 0 a los valores de x e y
%             meas.Z{k} = [0; 0];
%             meas.Z{k, 1}{1, 1} = 0;
%             meas.Z{k, 1}{2, 1} = 0;
            % Genera valores aleatorios para meas.Z{k, 1}{1, 1} entre [0,160]
             meas.Z{k, 1}{1, 1} = rand() * 160;

            % Genera valores aleatorios para meas.Z{k, 1}{2, 1} entre [0,120]
             meas.Z{k, 1}{2, 1} = rand() * 120;
        else
            % Inicializa celdas para x e y
            num_mediciones = numel(result_matrix) / 4;
            meas.Z{k, 1} = cell(2, num_mediciones);

            for i = 1:4:numel(result_matrix)
                % Extract the group of four values
                corners = result_matrix(i:i+3);

                % Calculate the center of the bounding box
                center_x = (corners(1) + corners(3)) / 2;
                center_y = (corners(2) + corners(4)) / 2;

                % Store the center coordinates in the cell array
                meas.Z{k, 1}{1, (i+3)/4} = center_x;
                meas.Z{k, 1}{2, (i+3)/4} = center_y;

                % Your additional processing for this group goes here
                disp(['Processing group ', num2str((i+3)/4)]);
            end
        end
    end
end







