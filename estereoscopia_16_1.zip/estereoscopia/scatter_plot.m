function X = scatter_plot(num_points, max_distance, max_height, fov_deg, sigma_vel)

fov_half = fov_deg / 2;
a = fov_half * pi / 180;

% Generar puntos aleatorios en el cuadrante positivo del espacio
theta = rand(1, num_points) * a * 2 - a;  % Ángulo de -fov/2 a fov/2 grados (en radianes)
rho = rand(1, num_points) * max_distance;
z = rand(1, num_points) * max_height;
vx = sigma_vel * randn(1, num_points);
vy = sigma_vel * randn(1, num_points);
vz = sigma_vel * randn(1, num_points);

% Convertir coordenadas polares a coordenadas cartesianas
x = rho .* cos(theta);
y = rho .* sin(theta);

X = [x; vx; y; vy; z; vz];
end

