function H = createHomogeneousMatrixFromROS(tx, ty, tz, rx, ry, rz)
%H = eul2tform([rz, ry, rx], 'XYZ'); %SI
H = eul2tform([rx,ry, rz], 'ZYX'); %NO %final
%H = eul2tform([rx,ry, rz], 'XYZ'); %SI
%H = eul2tform([rx, ry, rz], 'ZYZ'); NO
%'ZYX', 'ZYZ', and 'XYZ'
H(1:3, 4) = [tx; ty; tz];