function X = torta(X, alpha, max_height,rho)
    
    
    % Obtener las coordenadas x, y, z de cada columna
    x = X(1, :);
    y = X(2, :);
    z = X(3, :);

    % Evaluar las condiciones para cada partícula
    outside_volume = (y > -rho * sin(alpha/2) | y < rho * sin(alpha/2) | ...
                      x < 0 | x > rho * cos(alpha/2) | ...
                      z < 0 | z > max_height);
    
    % Transformar las partículas fuera del volumen a cero
    X(:, outside_volume) = 0
end

