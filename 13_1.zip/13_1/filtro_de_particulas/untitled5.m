
num_points = 100;
max_distance = 30;
max_height = 5;
fov_deg = 30;  % Rango de ángulo entre -30 y 30 grados
sigma_vel = 1;

% Convertir el rango de ángulo a radianes
a = fov_deg * pi / 180;

% Generar puntos aleatorios en el cuadrante positivo del espacio
theta = rand(1, num_points) * a - a/2;  % Ángulo de -30 a 30 grados (en radianes)
rho = rand(1, num_points) * max_distance;
z = rand(1, num_points) * max_height;
vx = sigma_vel * randn(1, num_points);
vy = sigma_vel * randn(1, num_points);
vz = sigma_vel * randn(1, num_points);

% Convertir coordenadas polares a coordenadas cartesianas
%x = rho .* cos(theta);
%y = rho .* sin(theta);
%vec=[x;y;z];
%uno=ones(1,size(vec,2));
%vecf=[vec;uno];

ProyectionMatrix = [155.4981, 0.0000, 74.7454, 0; 0.0000, 157.1137, 55.5787, 0; 0.0000, 0.0000, 1.0000, 0];
Haxis = createHomogeneousMatrixFromROS(0.0, 0.0, 0.0, -1.5708, 0.0, -1.5708);
Hcam = createHomogeneousMatrixFromROS(0.0, 0.0, 0.35, 0.0, 0.0, 0.0);
model.H = ProyectionMatrix* (inv(Hcam*Haxis))


%vproyh=model.H*vecf;

%t=[ [2.98; -1.35 ; -0.56; 1], [10; -3; 0; 1], [10; 3; 0; 1]];
t=[ [9.86; -4.19; 3.25 ; 1] ,[7.82; -2.75 ; 2.61; 1] , [2.98;1.25;-0.55;1],[3.09;0.803;-0.54;1], [13.8;3.65;4.22;1], [9.59; 4.54; 3.28; 1], [24;1.25;1.5;1] ]
vproyh=model.H* t

z_hat = vproyh(1:2, :) ./ vproyh(3, :)

% Eliminar la fila 3
if size(z_hat, 1) >= 3
    % Eliminar la fila 3
    z_hat(3, :) = [];
else
    disp('La matriz z_hat no tiene suficientes filas para eliminar la tercera fila.');
end 

z_hat;

x = t(1, :);
y = t(2, :);
z = t(3, :);

% Visualizar en un gráfico 3D
figure;
scatter3(x, y, z, 'filled');
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Distribución Aleatoria de Puntos en 3D');
%axis equal;
axis([0, 14, -12, 12, -0.6, 5]);

x2 = z_hat(1, :);
y2 = z_hat(2, :);

figure;
plot(x2, y2, 'o');
axis([0,160 , 0,120])
xlabel('X');
ylabel('Y');
title('Vectores en el Plano XY');

% Ajustar el aspecto del gráfico
%axis equal;
grid on;