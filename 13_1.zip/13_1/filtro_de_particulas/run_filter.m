function est = run_filter(model,meas)

%=== Setup

%output variables
est.X= cell(meas.K,1);
est.N= zeros(meas.K,1);
est.L= cell(meas.K,1);
est.X_update_values = cell(meas.K, 1);

%filter parameters
filter.J_max= 1000;                  %total number of particles

filter.run_flag= 'disp';            %'disp' or 'silence' for on the fly output

est.filter= filter;

%=== Filtering 

%initial prior
w_update= ones(filter.J_max,1)/filter.J_max;
% P_init= diag([100 10 100 10 100 10]).^2;
% m_init= [0.1;0;0.1;0;0.1;0];
%x_update= gen_gms(1,m_init,P_init,filter.J_max);
radio=30
altura=3
fov_deg=65
sigma_velo=1.0
x_update=init_distribution(filter.J_max,radio,altura,fov_deg,sigma_velo);




% figure;

% scatter3([], [], [], 'o');
% title('Dynamic 3D Plot of x_update');
% xlabel('X-axis');
% ylabel('Y-axis');
% zlabel('Z-axis');
% axis([0, 70, -15, 15, -0.6, 5]);
% view([0,90])
% grid on


%recursive filtering
for k=1:meas.K;
    %---prediction 
    x_predict = gen_newstate_fn(model,x_update,'noise'); %muevo las particulas
    w_predict= w_update
        
    %---update
%     compute_likelihood(model,meas.Z{k}(:,1),x_predict,fov_deg,altura,radio,k);
    likelihood = compute_likelihood(model,meas.Z{k}(:,1),x_predict,fov_deg,altura,radio,k,meas.hw{k}(:,1));  %calculo las probabilidad de las particulas "movidas"
    w_update= likelihood.*w_predict;   %actualizo los pesos de las particulas 
    x_update= x_predict;
            
    %normalize weights
    w_update = w_update/sum(w_update);        
%     w_update(:) = 1/length(w_update);        
    %---for diagnostics
    w_posterior= w_update;
    
%     ---resampling
    idx= randsample(length(w_update),filter.J_max,true,w_update) ;
    w_update= ones(filter.J_max,1)/filter.J_max ;
    x_update= x_update(:,idx) ;
    
    %--- state extraction
    est.X{k} = x_update*w_update;
    est.N(k)= 1;
    est.L{k}= [];
    est.X_update_values{k} = x_update ;
    
    
%     x_update_visualization = est.X_update_values{k};
% 
%     scatter3(x_update_visualization(1, :), x_update_visualization(2, :), ...
%              x_update_visualization(3, :), 'o', 'MarkerFaceColor', 'b');
% 
%     axis([0, 70, -15, 15, -0.6, 5]);
%     view ([0 90]);
%     title('Visualización de x update')

    % Actualizar la figura
%     drawnow;

    % Pausa para permitir la actualización y evitar el parpadeo
    pause(0.3);

    %---display diagnostics
    if ~strcmp(filter.run_flag,'silence')
        disp([' time= ',num2str(k),...
         ' Neff_updt= ',num2str(round(1/sum(w_posterior.^2)))...
         ' Neff_rsmp= ',num2str(round(1/sum(w_update.^2)))   ]);
    end
    
    % --- plot x_update in 3D
%     figure;
%     scatter3(x_update(1, :), x_update(3, :), x_update(5, :), 'o');
%     title(['Iteration ', num2str(k), ' - 3D Plot of x_update']);
%     xlabel('X-axis');
%     ylabel('Y-axis');
%     zlabel('Z-axis');
%     axis([0, 14, -12, 12, -0.6, 5]);
%     grid on;
    

    
end

            