function model= gen_model

% basic parameters
model.x_dim= 6;   %dimension of state vector
model.z_dim= 2;   %dimension of observation vector

% dynamical model parameters (CV model)
% model.T= 1.0/6;                                     %sampling period
model.T= 1.0/6;                                     %sampling period
model.A0= [ 1 model.T; 0 1 ];                         %transition matrix                     
model.F= [ model.A0 zeros(2,4); zeros(2,2) model.A0 zeros(2,2); zeros(2,4) model.A0];
model.B0= [ (model.T^2)/2; model.T ];
model.B= [ model.B0 zeros(2,2); zeros(2,1) model.B0 zeros(2,1); zeros(2,2) model.B0];
% model.B=  zeros(6, 3);
% model.sigma_V = 0.1;
model.sigma_V = 1.0;
model.Q= (model.sigma_V)^2* model.B*model.B';   %process noise covariance

% survival/death parameters
% N/A for single target

% birth parameters
% N/A for single target

% observation model parameters (noisy x/y only)
model.OH= [ 1 0 0 0 0 0; 0 0 1 0 0 0; 0 0 0 0 1 0 ];    %observation matrix
model.D= diag([ 1; 1 ]); 
model.R= model.D*model.D';              %observation noise covariance
%ProyectionMatrix = [211.06312561, 0.0, 101.45460085, 0.0;  
%                    0.0, 156.13174438,  55.23133321, 0.0;
%                    0.0, 0.0, 1.0, 0 ];
%Haxis = createHomogeneousMatrixFromROS(0.0, 0.0, 0.0, -1.5708, 0.0, -1.5708);
%Hcam = createHomogeneousMatrixFromROS(0.0, 0.0, 0.35, 0.0, 0.0, 0.0);
%model.H = ProyectionMatrix*((Haxis*Hcam)\H);

% ProyectionMatrix = [211.06312561, 0.0, 101.45460085,0;  
%                     0.0, 156.13174438,  55.23133321,0;
%                     0.0, 0.0, 1.0 , 0.0 ];
ProyectionMatrix = [155.4981, 0.0000, 74.7454, 0.0000;
                    0.0000, 157.1137, 55.5787, 0.0000;
                    0.0000, 0.0000, 1.0000, 0.0000]
Haxis = createHomogeneousMatrixFromROS(0.0, 0.0, 0.0, -1.5708, 0.0, -1.5708);
Hcam = createHomogeneousMatrixFromROS(0.0, 0.0, 0.35, 0.05, 0.0, 0.0);
model.H = ProyectionMatrix* (inv(Hcam*Haxis));


% detection parameters
% use compute_pD for state dependent parameterization
% use compute_qD for state dependent parameterization

% clutter parameters
% model.lambda_c= 20;                             %poisson average rate of uniform clutter (per scan)
% model.range_c= [ -1000 1000; -1000 1000 ];      %uniform clutter region
% model.pdf_c= 1/prod(model.range_c(:,2)-model.range_c(:,1)); %uniform clutter density




