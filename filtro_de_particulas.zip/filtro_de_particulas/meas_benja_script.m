function meas = gen_meas()
    % Especifica la ruta de tu archivo CSV
    archivo_csv = '/home/benjamin/Desktop/results.csv';

    % Lee el archivo CSV
    tabla_datos = readtable(archivo_csv);

    % variables
    n = size(tabla_datos, 1);
    meas.K = n;
    meas.Z = cell(n, 1); % Cambiado a 1 columna

    % generate measurements
    for k = 1:n
        % Extrae result de los datos de la tabla
        corners = eval(tabla_datos.result{k});

        % Calcula el centro del cuadro delimitador
        center_x = (corners(1) + corners(3)) / 2;
        center_y = (corners(2) + corners(4)) / 2;

        % Almacena las coordenadas x e y en una celda
        meas.Z{k} = {center_x; center_y}; % Cada elemento es una celda
    end
end








