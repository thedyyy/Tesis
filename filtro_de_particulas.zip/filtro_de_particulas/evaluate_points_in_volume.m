% function particle_matrix = evaluate_points_in_volume(X, max_height, alpha)
% 
%     % Extraer coordenadas x, y, z de la matriz X
%     x_sphere = X(1, :);
%     y_sphere = X(2, :);
%     z_sphere = X(3, :);
% 
%     % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
%     x_min = min(x_sphere);
%     x_sphere = x_sphere - x_min;
% 
%     % Definir límites del "diamante" y de la altura
%     angle_lower_limit = -alpha / 2;
%     angle_upper_limit = alpha / 2;
%     height_lower_limit = -max_height;
%     height_upper_limit = max_height;
% 
%     % Filtrar puntos fuera del "diamante" y del límite de altura
%     angles = atan2d(y_sphere, x_sphere);
%     distances = sqrt(x_sphere.^2 + y_sphere.^2 + z_sphere.^2);
% 
%     valid_indices = find(angles >= angle_lower_limit & angles <= angle_upper_limit & ...
%                          y_sphere >= height_lower_limit & y_sphere <= height_upper_limit & ...
%                          z_sphere >= -0.6 & distances <= max(distances));
% 
%     % Crear matriz de partículas
%     particle_matrix = zeros(4, length(x_sphere));
%     
%     % Asignar valores a las partículas dentro del volumen
%     particle_matrix(1:3, valid_indices) = [x_sphere(valid_indices); y_sphere(valid_indices); z_sphere(valid_indices)];
%     particle_matrix(4, valid_indices) = 1; % Agregar una cuarta fila de unos para indicar que está dentro del volumen
% 
%     % Visualizar puntos después de la evaluación
%     figure;
%     scatter3(particle_matrix(1, :), particle_matrix(2, :), particle_matrix(3, :), 'o', 'MarkerFaceColor', 'r');
%     title('Puntos después de Evaluación');
%     xlabel('X-axis');
%     ylabel('Y-axis');
%     zlabel('Z-axis');
%     axis equal;
%     grid on;
%     
%     particle_matrix;
% 
% end


% function particle_matrix = evaluate_points_in_volume(X, max_height, alpha)
% 
%     % Extraer coordenadas x, y, z de la matriz X
%     x_sphere = X(1, :);
%     y_sphere = X(2, :);
%     z_sphere = X(3, :);
% 
%     % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
%     x_min = min(x_sphere);
%     x_sphere_adjusted = x_sphere - x_min;
% 
%     % Definir límites del "diamante" y de la altura
%     angle_lower_limit = -alpha / 2;
%     angle_upper_limit = alpha / 2;
%     height_lower_limit = -max_height;
%     height_upper_limit = max_height;
% 
%     % Filtrar puntos fuera del "diamante" y del límite de altura
%     angles = atan2d(y_sphere, x_sphere_adjusted);
%     distances = sqrt(x_sphere_adjusted.^2 + y_sphere.^2 + z_sphere.^2);
% 
%     valid_indices = find(angles >= angle_lower_limit & angles <= angle_upper_limit & ...
%                          y_sphere >= height_lower_limit & y_sphere <= height_upper_limit & ...
%                          z_sphere >= -0.6 & distances <= max(distances));
% 
%     % Crear matriz de partículas
%     particle_matrix = zeros(4, length(x_sphere));
%     
%     % Asignar valores a las partículas dentro del volumen sin cambiar X
%     particle_matrix(1:3, valid_indices) = [x_sphere(valid_indices); y_sphere(valid_indices); z_sphere(valid_indices)];
%     particle_matrix(4, valid_indices) = 1; % Agregar una cuarta fila de unos para indicar que está dentro del volumen
% 
%     % Visualizar puntos después de la evaluación
%     figure;
%     scatter3(particle_matrix(1, :), particle_matrix(2, :), particle_matrix(3, :), 'o', 'MarkerFaceColor', 'r');
%     title('Puntos después de Evaluación');
%     xlabel('X-axis');
%     ylabel('Y-axis');
%     zlabel('Z-axis');
%     axis([-50, 50, -12, 12, -0.6, 5]);
%     grid on;
%     
%     particle_matrix;
% 
% end



function particle_matrix = evaluate_points_in_volume(X, max_height, alpha , radio)

    % Extraer coordenadas x, y, z de la matriz X
    x_sphere = X(1, :);
    y_sphere = X(2, :);
    z_sphere = X(3, :);

    % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
    x_min = min(x_sphere);
    x_sphere_adjusted = x_sphere - x_min;

    % Definir límites del "diamante" y de la altura
    angle_lower_limit = -alpha / 2;
    angle_upper_limit = alpha / 2;
    height_lower_limit = -max_height;
    height_upper_limit = max_height;

    % Filtrar puntos dentro del cono
    angles = atan2d(y_sphere, x_sphere_adjusted);
    valid_indices = (angles >= angle_lower_limit) & (angles <= angle_upper_limit);

    % Crear matriz de partículas
    particle_matrix = zeros(4, length(x_sphere));
    
    % Asignar valores a las partículas dentro del cono
    particle_matrix(1:3, valid_indices) = [x_sphere(valid_indices); y_sphere(valid_indices); z_sphere(valid_indices)];
    particle_matrix(4, valid_indices) = 1; % Asignar 1 a la cuarta fila para indicar que está dentro del cono
    particle_matrix
    
    % Visualizar puntos después de la evaluación
    figure;
    scatter3(particle_matrix(1, :), particle_matrix(2, :), particle_matrix(3, :), 'o', 'MarkerFaceColor', 'r');
    title('Puntos después de Evaluación');
    xlabel('X-axis');
    ylabel('Y-axis');
    zlabel('Z-axis');
    axis([0, 70, -15, 15, -0.6, 5]);
    grid on;
    
end








