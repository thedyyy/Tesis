
num_points = 100;
max_distance = 30;
max_height = 5;
fov_deg = 30;  % Rango de ángulo entre -30 y 30 grados
sigma_vel = 1;

% Convertir el rango de ángulo a radianes
a = fov_deg * pi / 180;

% Generar puntos aleatorios en el cuadrante positivo del espacio
theta = rand(1, num_points) * a - a/2;  % Ángulo de -30 a 30 grados (en radianes)
rho = rand(1, num_points) * max_distance;
z = rand(1, num_points) * max_height;
vx = sigma_vel * randn(1, num_points);
vy = sigma_vel * randn(1, num_points);
vz = sigma_vel * randn(1, num_points);

% Convertir coordenadas polares a coordenadas cartesianas
x = rho .* cos(theta);
y = rho .* sin(theta);
vec=[x;y;z];
uno=ones(1,size(vec,2));
vecf=[vec;uno];

ProyectionMatrix = [211.06312561, 0.0, 101.45460085,0;  
                    0.0, 156.13174438,  55.23133321,0;
                    0.0, 0.0, 1.0 , 0.0 ];
Haxis = createHomogeneousMatrixFromROS(0.0, 0.0, 0.0, -1.5708, 0.0, -1.5708);
Hcam = createHomogeneousMatrixFromROS(0.0, 0.0, 0.35, 0.0, 0.0, 0.0);
model.H = ProyectionMatrix* ((Hcam*Haxis))

vproyh=model.H*vecf

z_hat = vproyh(1:2, :) ./ vproyh(3, :)

% Eliminar la fila 3
if size(z_hat, 1) >= 3
    % Eliminar la fila 3
    z_hat(3, :) = [];
else
    disp('La matriz z_hat no tiene suficientes filas para eliminar la tercera fila.');
end 

z_hat

% Visualizar en un gráfico 3D
figure;
scatter3(x, y, z, 'filled');
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Distribución Aleatoria de Puntos en 3D');
axis equal;

x2 = z_hat(1, :);
y2 = z_hat(2, :);

figure;
plot(x2, y2, 'o');
xlabel('X');
ylabel('Y');
title('Vectores en el Plano XY');

% Ajustar el aspecto del gráfico
axis equal;
grid on;

