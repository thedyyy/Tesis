function center = obtener_centro_desde_csv(k)
    % Especifica la ruta de tu archivo CSV
    archivo_csv = '/home/benjamin/Desktop/results4.csv';

    % Lee el archivo CSV
    tabla_datos = readtable(archivo_csv);

    % Extrae result de los datos de la tabla
    corners = eval(tabla_datos.result{k});

    % Calcula el centro del cuadro delimitador
    x1=corners(1)
    x2=corners(3)
    y1=corner(2)
    y2=corners(4)

    center=[x1,x2,x2,x1];[y1,y2,y1,y2]
    
end


