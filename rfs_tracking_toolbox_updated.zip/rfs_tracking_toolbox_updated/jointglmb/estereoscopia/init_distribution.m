function X = init_distribution(num_points, max_distance, max_height, fov_deg, sigma_vel)


a = fov_deg*pi/180;

% Generar puntos aleatorios en el cuadrante positivo del espacio
theta = rand(1, num_points) * a - a/2;  % Ángulo de 0 a 60 grados (en radianes)
rho = rand(1, num_points) * max_distance;
%z = rand(1, num_points) * max_height;
z = rand(1, num_points) * (max_height + 1) - 1;

vx = sigma_vel * randn(1, num_points);
vy = sigma_vel * randn(1, num_points);
vz = sigma_vel * randn(1, num_points);

% Convertir coordenadas polares a coordenadas cartesianas
x = rho .* cos(theta);
y = rho .* sin(theta);

X = [x;vx;y;vy;z;vz];

figure;
scatter3(x, y, z, 'filled');
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Distribución Aleatoria de Puntos en 3D , init_dist')