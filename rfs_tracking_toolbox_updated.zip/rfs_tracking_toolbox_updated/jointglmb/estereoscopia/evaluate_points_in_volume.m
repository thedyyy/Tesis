

function valid_indices = evaluate_points_in_volume(X, max_height, alpha, radio, k)

    % Extraer coordenadas x, y, z de la matriz X
    x_sphere = X(1, :);
    y_sphere = X(3, :);
    z_sphere = X(5, :);

    % Ajustar la posición para centrar el "diamante" en el eje y, partiendo de x=(0,0)
%     x_min = min(x_sphere);
    x_sphere_adjusted = x_sphere ;

    % Definir límites del "diamante" y de la altura
    angle_lower_limit = -alpha / 2;
    angle_upper_limit = alpha / 2;
    height_lower_limit = -0.7;
    height_upper_limit = max_height;

    % Filtrar puntos dentro del cono
    angles = atan2d(y_sphere, x_sphere_adjusted);
    valid_indices = (angles >= angle_lower_limit) & (angles <= angle_upper_limit) & ...
                    (z_sphere >= height_lower_limit) & (z_sphere <= height_upper_limit) & ...
                    sqrt(x_sphere_adjusted.^2 + y_sphere.^2) <= radio; % Condición para el radio
    
    % Actualizar el vector de entrada X
%     X_new = X;
%     X_new(:, ~valid_indices) = 0;


    % Visualizar puntos después de la evaluación
%     figure;
%     scatter3(X_new(1, :), X_new(3, :), X_new(5, :), 'o', 'MarkerFaceColor', 'r');
%     title(['Puntos después de Evaluación frame numero ' num2str(k) ]);
%     xlabel('X-axis');
%     ylabel('Y-axis');
%     zlabel('Z-axis');
%     axis([0, 70, -15, 15, -0.6, 5]);
%     view([0 90]);
% 
%     grid on;
    
end










